// Навигационное меню для мобильных устройств
document.querySelector('.menu-toggle').addEventListener('click', function() {
    document.querySelector('.nav-menu').classList.toggle('active');
});

// Плавная прокрутка к якорям с учётом высоты фиксированного меню
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        const nav = document.querySelector('nav');

        if (targetElement) {
            const navHeight = nav ? nav.offsetHeight : 0;
            // Для блока "Давайте знакомиться!" (#about-me) даём чуть больший запас, чтобы заголовок не прятался под шапкой
            const extraOffset = targetId === '#about-me' ? 30 : 0;
            const targetTop = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight + extraOffset;

            window.scrollTo({
                top: targetTop,
                behavior: 'smooth'
            });
        }

        // Закрываем меню на мобильных устройствах после клика
        const navMenu = document.querySelector('.nav-menu');
        if (navMenu) {
            navMenu.classList.remove('active');
        }
    });
});

// Обработка формы
document.getElementById('consultation-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Спасибо за вашу заявку! Я свяжусь с вами в ближайшее время.');
    this.reset();
});

// Изменение навигации при прокрутке
window.addEventListener('scroll', function() {
    const nav = document.querySelector('nav');
    if (window.scrollY > 50) {
        nav.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        nav.style.padding = '5px 0';
    } else {
        nav.style.boxShadow = 'none';
        nav.style.padding = '15px 0';
    }
});

// Улучшенная карусель отзывов
class TestimonialSlider {
    constructor() {
        // Проверяем существование элементов перед инициализацией
        this.slides = document.querySelectorAll('.testimonial-slide');
        this.indicators = document.querySelectorAll('.testimonial-indicator');
        this.prevBtn = document.querySelector('.testimonial-prev');
        this.nextBtn = document.querySelector('.testimonial-next');

        // Если элементы не найдены, выходим из конструктора
        if (this.slides.length === 0 || !this.prevBtn || !this.nextBtn) {
            console.warn('Элементы карусели отзывов не найдены');
            return;
        }

        this.currentSlide = 0;
        this.autoPlayInterval = null;

        this.init();
    }

    init() {
        // Показываем первый слайд
        this.showSlide(this.currentSlide);

        // Добавляем обработчики событий
        this.prevBtn.addEventListener('click', () => this.prevSlide());
        this.nextBtn.addEventListener('click', () => this.nextSlide());

        // Добавляем обработчики для индикаторов
        this.indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => this.showSlide(index));
        });

        // Запускаем автоматическое перелистывание
        this.startAutoPlay();

        // Останавливаем автоматическое перелистывание при наведении на слайдер
        const slider = document.querySelector('.testimonial-slider');
        if (slider) {
            slider.addEventListener('mouseenter', () => this.stopAutoPlay());
            slider.addEventListener('mouseleave', () => this.startAutoPlay());
        }
    }

    showSlide(index) {
        // Скрываем все слайды
        this.slides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Убираем активный класс со всех индикаторов
        this.indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });

        // Корректируем индекс, если он вышел за границы
        if (index >= this.slides.length) {
            this.currentSlide = 0;
        } else if (index < 0) {
            this.currentSlide = this.slides.length - 1;
        } else {
            this.currentSlide = index;
        }

        // Показываем текущий слайд
        this.slides[this.currentSlide].classList.add('active');

        // Активируем соответствующий индикатор
        if (this.indicators[this.currentSlide]) {
            this.indicators[this.currentSlide].classList.add('active');
        }
    }

    nextSlide() {
        this.showSlide(this.currentSlide + 1);
    }

    prevSlide() {
        this.showSlide(this.currentSlide - 1);
    }

    startAutoPlay() {
        this.stopAutoPlay(); // Останавливаем предыдущий интервал, если он был
        this.autoPlayInterval = setInterval(() => {
            this.nextSlide();
        }, 5000); // Меняем слайд каждые 5 секунд
    }

    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
}

// Показ модального окна при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация карусели отзывов
    const hasTestimonials = document.querySelector('.testimonial-slider') &&
        document.querySelectorAll('.testimonial-slide').length > 0;

    if (hasTestimonials) {
        new TestimonialSlider();
    }

    // Показываем модальное окно через 3 секунды после загрузки
    setTimeout(function() {
        showModal();
    }, 3000);

    // Добавляем обработчик закрытия модального окна только если элемент существует
    const closeModalBtn = document.querySelector('.close-modal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeModal);
    } else {
        console.warn('Элемент .close-modal не найден');
    }

    // Добавляем обработчики форм только если они существуют
    const modalForm = document.getElementById('modalForm');
    const footerForm = document.getElementById('footerForm');

    if (modalForm) {
        modalForm.addEventListener('submit', handleModalFormSubmit);
    } else {
        console.warn('Форма modalForm не найдена');
    }

    if (footerForm) {
        footerForm.addEventListener('submit', handleFooterFormSubmit);
    } else {
        console.warn('Форма footerForm не найдена');
    }
});

// Функции для модального окна
function showModal() {
    const modal = document.getElementById('contactModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeModal() {
    const modal = document.getElementById('contactModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Закрытие модального окна при клике вне его
window.addEventListener('click', function(event) {
    const modal = document.getElementById('contactModal');
    if (modal && event.target === modal) {
        closeModal();
    }
});


async function sendContact(formData) {
    try {
        const response = await fetch('send.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        const contentType = response.headers.get('Content-Type') || '';

        // Если статус не 2xx — читаем текст и логируем, без попытки парсить JSON
        if (!response.ok) {
            const text = await response.text();
            console.error('Ошибка ответа сервера:', response.status, text);
            return false;
        }

        // Если сервер вернул JSON — корректно парсим
        if (contentType.includes('application/json')) {
            const result = await response.json();
            return !!result.success;
        } else {
            const text = await response.text();
            console.error('Ожидался JSON, но получен другой формат:', text);
            return false;
        }
    } catch (error) {
        console.error('Ошибка отправки заявки:', error);
        return false;
    }
}

// Обработчик формы модального окна
async function handleModalFormSubmit(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('modalName').value,
        phone: document.getElementById('modalPhone').value,
        message: document.getElementById('modalMessage').value,
        email: ''
    };

    const success = await sendContact(formData, 'Модальное окно');
    
    if (success) {
        alert('Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в течение 15 минут.');
        closeModal();
        e.target.reset();
    } else {
        alert('Произошла ошибка при отправке. Пожалуйста, попробуйте еще раз или позвоните нам.');
    }
}

// Обработчик формы в футере
async function handleFooterFormSubmit(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('footerName').value,
        phone: document.getElementById('footerPhone').value,
        email: document.getElementById('footerEmail').value,
        message: document.getElementById('footerMessage').value
    };

    const success = await sendContact(formData, 'Форма в футере');
    
    if (success) {
        alert('Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в течение 15 минут.');
        e.target.reset();
    } else {
        alert('Произошла ошибка при отправке. Пожалуйста, попробуйте еще раз или позвоните нам.');
    }
}
