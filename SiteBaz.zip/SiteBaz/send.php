<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Preflight-запросы CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Метод не разрешен']);
    exit;
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);

if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Некорректные данные']);
    exit;
}

$name = trim($input['name'] ?? '');
$phone = trim($input['phone'] ?? '');
$email = trim($input['email'] ?? '');
$messageText = trim($input['message'] ?? '');

if ($name === '' || $phone === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Укажите имя и телефон']);
    exit;
}

$botToken = '8597633363:AAGPhMru2NlHyIK3WgjgICJGnvbGfK04eLc';
$chatId = '1935224328';

$message = "📞 Новая заявка с сайта\n\n";
$message .= "👤 Имя: " . $name . "\n";
$message .= "📱 Телефон: " . $phone . "\n";
$message .= "📧 Email: " . ($email !== '' ? $email : 'Не указан') . "\n";
$message .= "💬 Сообщение: " . ($messageText !== '' ? $messageText : 'Не указано') . "\n\n";
$message .= "🕒 Время: " . date('Y-m-d H:i:s');

$url = "https://api.telegram.org/bot{$botToken}/sendMessage";
$payload = [
    'chat_id' => $chatId,
    'text' => $message,
    'parse_mode' => 'HTML'
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 20,
    CURLOPT_POSTFIELDS => http_build_query($payload),
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
]);

$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($result === false) {
    http_response_code(502);
    echo json_encode(['success' => false, 'error' => 'Ошибка отправки: ' . $curlError]);
    exit;
}

$response = json_decode($result, true);
if ($httpCode === 200 && isset($response['ok']) && $response['ok'] === true) {
    http_response_code(200);
    echo json_encode(['success' => true]);
} else {
    http_response_code(502);
    $err = $response['description'] ?? ('HTTP ' . $httpCode);
    echo json_encode(['success' => false, 'error' => 'Ошибка Telegram: ' . $err]);
}
